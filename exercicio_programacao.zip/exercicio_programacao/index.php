<?php

if (isset($_GET['acao'])){
    $acao = $_GET['acao'];
}else{
    $acao = 'index';
}

require 'app/models/CategoriaCrud.php';

switch ($acao){
    case 'index':

        $crud = new CategoriaCrud();
        $categorias = $crud->getCategorias();

        include_once 'app/view/index.php';
        break;
}
