<?php

if (isset($_GET['acao'])){
    $acao = $_GET['acao'];
}else{
    $acao = 'index';
}

require_once 'app/models/CategoriaCrud.php';
require_once 'app/models/ProdutoCrud.php';

switch ($acao){
    case 'index':

        $crud = new CategoriaCrud();
        $categorias = $crud->getCategorias();
        $crudP = new ProdutoCrud();
        $produtos = $crudP->getProdutos();

        include_once 'app/view/index.php';
        break;
}
