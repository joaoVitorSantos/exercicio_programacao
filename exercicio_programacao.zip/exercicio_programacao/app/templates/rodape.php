<footer class="footer rodape">
    <link rel="stylesheet" href="../assets/mycss/mycss.css">
    <div class="container">
        <span class="text-muted">João Vitor e Vinicius 3info1</span>
    </div>
</footer>
</body>
</html>