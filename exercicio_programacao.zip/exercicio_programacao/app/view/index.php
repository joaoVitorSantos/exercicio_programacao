<html>
    <head>
        <title></title>
        <link rel="stylesheet" href="mycss.css">

        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <script>

$(document).ready(function () {
    $("#abas ul li").addClass("selecionado");


    $("#abas ul li").click(function () {
        $(this).toggleClass("selecionado");
        var meuId = $(this).attr("id");
        $("."+meuId).toggle();
    })
            })
        </script>
            <body>

                <div id="abas">
                        <ul>
                            <?php foreach($categorias as $categoria):?>
                            <li id="aba<?=$categoria->getId()?>"><?= $categoria->getNome()?></li>
                            <?php endforeach; ?>
                        </ul>
                </div>

                <div id="conteudos">
                    <div class="conteudo aba1">
                        Conteúdo da aba1
                    </div>
                </div>
            </body>
    </head>
</html>
