<html>
    <head>
        <title></title>
        <link rel="stylesheet" href="mycss.css">

        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <script>

$(document).ready(function () {
    $("#abas ul li").addClass("selecionado");


    $("#abas ul li").click(function () {
        $(this).toggleClass("selecionado");
        var meuId = $(this).attr("id");
        $("."+meuId).toggle();

        $("titulo").click(function () {
            var elemPai = $(this).parent();
            elemPai.find(".descricao").toggle();

        })

    })
            })
        </script>
            <body>

                <div id="abas">
                        <ul>
                            <?php foreach($categorias as $categoria):?>
                            <li id="aba<?=$categoria->getId()?>"><?= $categoria->getNome()?></li>
                            <?php endforeach; ?>
                        </ul>
                </div>


                            <div id="conteudos">
                                <div class="conteudo aba">
                                    <?php foreach ($produtos as $produto):?>
                                        <div class="conteudo aba<?= $produto->getId()?>">
                                            <div class="titulo"><?= $produto->getNome()?></div>
                                            <div class="descricao"><?= $produto->getDescricao()?></div>
                                        </div>
                                    <?php endforeach;?>
                                </div>
                            </div>




            </body>
    </head>
</html>
