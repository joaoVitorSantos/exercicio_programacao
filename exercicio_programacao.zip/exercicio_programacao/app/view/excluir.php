<html>
    <head>
        <body>
            <?php require_once "../controller/ProdutoController.php" ?>

            <p>Nome: <?= $produto->getNome()?></p>
            <p>Descrição: <?= $produto->getDescricao()?></p>
            <p>Preço: <?= $produto->getPreco()?></p>
        </body>
    </head>
</html>